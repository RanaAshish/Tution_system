{

"header" : {
  "navbar" : {
    "DASHBOARD" : "主页",
    "EMAIL" : "邮件",
    "UIKITS" : "组件",
    "PAGES" : "页面"
  }
}

}
