## Release v.1.0.2:

#### Features:

 - Upgrade AngularJS to 1.4.3
 - Add swig fiies for generate the html folder
 - Add inbox app
 - Scroll page to top when state change

#### Bugfixes:

 - Fix html float label input
 - Fix html menu on mobile



## Release v1.0.1:

#### Features:

 - Add HTML version

#### Bugfixes:

 - Update angular-material to 0.9.0-rc3 to fix the double click event on mobile.
