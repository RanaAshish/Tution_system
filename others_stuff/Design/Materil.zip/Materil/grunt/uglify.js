module.exports = {
	angular:{
    src:[
      'angular/scripts/app.src.js'
    ],
    dest:'angular/scripts/app.min.js'
  },
  html:{
    src:[
      'html/scripts/app.src.js'
    ],
    dest:'html/scripts/app.min.js'
  }
}
