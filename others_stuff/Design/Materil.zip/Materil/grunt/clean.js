module.exports = {
  angular: ['angular/*'],
  html: ['html/*']
};
